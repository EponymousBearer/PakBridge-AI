# PakBridge AI — Crisis Intelligence Hub Handbook
## Comprehensive Product Manual & Operations Guide

Welcome to the **PakBridge AI** operations manual. PakBridge AI is a state-of-the-art emergency orchestration framework and intelligence hub designed to streamline catastrophe management, resource allocation, and civil-civilian synchronization across Pakistan during high-stakes crises (such as flash floods, fires, heatwaves, or medical contingencies).

This document serves as an exhaustive guide to understanding, testing, operating, and maximizing the benefits of the PakBridge AI platform.

---

## 1. Executive Summary & App Concept

During catastrophic events, communication breakdowns and sluggish manual coordination often cost lives. PakBridge AI addresses this by deploying an autonomous **Multi-Agent Orchestration Pipeline** that transforms unstructured civilian distress calls into actionable emergency dispatches in seconds.

### Key Pillars of the Application:
1. **Intelligent Localization**: Dual support for English, standard Urdu, and phonetic Roman Urdu to bridge the gap for first responders and regional operators.
2. **Multi-Agent Simulation**: Five specialized digital agents collaborate sequentially to ingest raw information, classify severe threats, plan medical/evacuation routines, translate summaries, and dispatch commands.
3. **Visual Core Command**: An interactive real-time mapping radar and advanced before-vs-after analytics dashboard to track response times and municipal workloads.
4. **Premium Design Language**: Grounded in futuristic, cyber-tactical styling. Built with dynamic dark glassmorphic panels, animated radar sweeps, glow matrices, and high-contrast indicators.

---

## 2. Technical Setup & Deployment Flow

PakBridge AI is built on **Expo SDK 54**, React Native, Reanimated, NativeWind (Tailwind CSS v3), and Lucide Icons.

### Step 1: Pre-requisites
- **Node.js**: Ensure Node.js v18+ is installed on your workstation.
- **Expo Go App**: Download the "Expo Go" app from the Google Play Store or iOS App Store on your test device.

### Step 2: Environment Variables
Create a file named `.env` in the root of the project to enable live integrations:
```env
# Google Gemini API Key (Required for live threat scoring and localization)
EXPO_PUBLIC_GEMINI_API_KEY=your_gemini_api_key_here

# Firebase Configurations (Optional; fallback offline databases exist)
EXPO_PUBLIC_FIREBASE_API_KEY=your_firebase_key
EXPO_PUBLIC_FIREBASE_AUTH_DOMAIN=your_project.firebaseapp.com
EXPO_PUBLIC_FIREBASE_PROJECT_ID=your_project_id
```

### Step 3: Launching the App
1. Install project dependencies:
   ```powershell
   npm install
   ```
2. Start the local server using the customized **ngrok tunneling mechanism**:
   ```powershell
   npx expo start --tunnel
   ```
3. **Scan QR Code**: Scan the QR code displayed in your terminal using your phone camera (iOS) or the Expo Go application (Android).

---

## 3. End-to-End Testing Walkthrough (Flow to Test)

Follow these exact steps to verify the entire system is operating without errors:

```mermaid
graph TD
    A[Launch App: Splash Screen] -->|Simulated Satellite Sync| B[Home Command Center]
    B -->|Explore Recent Alerts| C[Live Map Layer Filter]
    B -->|Navigate to Chat| D[Select English/Urdu/Roman Urdu]
    D -->|Input Crisis Description| E[Trigger Agent Workflow]
    E -->|Step 1: Retrieval Agent| F[Step 2: Live Gemini Analysis]
    F -->|Step 3: Reasoning Agent| G[Step 4: Localization & Translation]
    G -->|Step 5: NDMA/1122 Dispatch| H[Launch Impact Analytics Dashboard]
```

### Step-by-Step Test Sequence:

#### 1. Secure Boot Execution (Splash Screen)
- **Action**: Launch the application.
- **Observation**: You will see a dark cybernetic splash screen reading **PAKBRIDGE AI** with an active turquoise radar pulse. The progress tracker will cycle sequentially through telemetry stages (*"Syncing Neural Matrix..."*, *"Establishing Secure Satellite Link..."*, *"PakBridge AI Command Center Ready."*) within 2.8 seconds.
- **Expected Result**: Transitions smoothly into the main home interface.

#### 2. Home Dashboard & Signal Ingestion
- **Action**: Scroll through the **Recent Detections** on the main tab.
- **Observation**: Read pre-seeded cards showing ongoing crises (Swat Flooding, Gulberg Medical, Karachi Heatwave) paired with computer-vision-style satellite links.
- **Expected Result**: Elements render responsively with no lag or UI clipping.

#### 3. Language Selection & Distress Logging
- **Action**: Tap on the **AI Chat** tab.
- **Observation**: Notice the glowing "Neural Link Active" badge.
- **Test Option**: Tap the language button in the upper-right corner. It cycles through `English`, `Urdu` (عربی رسم الخط), and `Roman Urdu` (Urdu text in English alphabets), changing the search bar's placeholder text dynamically.
- **Expected Result**: Placeholders and state update instantly.

#### 4. Triggering the Multi-Agent Pipeline
- **Action**: Type a distress call in the text box (e.g., *"There is a sudden fire in a commercial building in Peshawar and people are stuck on the second floor!"*) and press the **Send Button**.
- **Observation**: You are redirected to the **Agent Orchestration modal** (`src/app/workflow/[id].tsx`).
- **Telemetry Verification**:
  - **Retrieval Agent (Blue)**: Runs a 1.2-second check querying mock sensor feeds.
  - **Crisis Detection Agent (Peach)**: Initiates a **live call to Gemini AI** (or fallback parser if API keys are absent) to extract category (`Fire`), severity (`Critical`), and action plans.
  - **Reasoning Agent (Cyan)**: Generates operational steps for first responders.
  - **Simplification Agent (Sky Blue)**: Translates citizen-facing instructions into your active selected language (English, Urdu, or Roman Urdu).
  - **Action Execution Agent (Indigo)**: Sends the final dispatch package to the Emergency Civil Command APIs (NDMA and Rescue 1122).
- **Expected Result**: After all 5 steps complete, a success badge reading `ONLINE` lights up next to each step, and a prominent blue button **"Launch Impact Analytics"** appears at the bottom.

#### 5. Impact Analytics Evaluation
- **Action**: Tap **Launch Impact Analytics**.
- **Observation**: You will be navigated directly to the **Dashboard Screen** showing key indicators: "Response Latency: 0.8s" and a graphic comparing "Evacuation & Dispatch Latency" before AI (34 minutes) versus after AI (0.8 seconds).
- **Expected Result**: Circular indicators and progress bars represent regional risk loads accurately.

#### 6. Interactive Radar Inspection
- **Action**: Tap the **Live Map** tab.
- **Observation**: A specialized mapping module (`MapView`) loads.
- **Test Option**: Tap the bottom category filters (*🛰️ All Signals*, *🌊 Flooding*, *🚑 Medical ER*, *🔥 Fire Outbreak*).
- **Expected Result**: The map markers filter instantly to show only locations relevant to the active layer selection.

---

## 4. Feature Taxonomy: Live vs. Static Systems

To help you understand the boundaries of the present application build, the following table details which features are fully dynamic (live-integrated with APIs/databases/state-managers) versus simulated (mocked or pre-seeded):

| Feature Area | Implementation Type | Technical Detail |
| :--- | :--- | :--- |
| **Language Selection Engine** | **LIVE** | Implemented using a Zustand global store (`appStore.ts`). Changing languages instantly modifies instructions in Chat and translating pipelines. |
| **Crisis Analysis & Classification** | **LIVE** | Integrated with **Google Gemini 1.5 Flash API**. Sends your raw text to Gemini and retrieves categorizations, severity, and custom survival action plans. |
| **State Persistence & Storage** | **LIVE** | Controlled dynamically via `crisisStore.ts` and `agentStore.ts`. Logging a new alert inserts a record into memory and updates active dashboards. |
| **Urdu / Roman Urdu Translation** | **LIVE** | Uses Gemini to translate advice on-the-fly, serving Urdu scripts or phonetics based on user setting. |
| **Satellite Sync Sequence** | *SIMULATED* | The splash boot sequence represents a mock satellite linkage delay of 2.8 seconds to enhance user engagement. |
| **Civil Dispatch APIs (1122 / NDMA)** | *SIMULATED* | Action execution completes after a mock server latency delay of 1.2 seconds, simulating active webhooks. |
| **Map Base Tile Rendering** | **LIVE** | Renders live satellite or street tiles using **react-native-maps** on native devices and open-source maps on web wrappers. |
| **Drone Imagery & Hotspot Links** | *SIMULATED* | Standardized Google cloud storage links are used to mock active regional drone feeds on the homepage. |

---

## 5. High-Value Real-World Use Cases

PakBridge AI is engineered for civic, governmental, and volunteer utility. Below are the primary environments where PakBridge AI delivers immense value:

### Use Case A: Automated NDMA Incident Logging
- **Scenario**: Severe rainstorms hit Northern Pakistan. Multiple local reports flood in via text or voice.
- **Benefit**: Instead of operators manually reading and logging each report, PakBridge AI ingests raw Urdu/Roman Urdu reports, standardizes them, calls Gemini to classify their severity, and updates the regional NDMA dashboard instantly.
- **Outcome**: Minimizes triage lag from hours to under 1 second.

### Use Case B: Pre-Emptive Rescue 1122 Dispatching
- **Scenario**: A civilian reports a major traffic collision on the motorway.
- **Benefit**: The multi-agent pipeline extracts the geographical coordinates, categorizes the urgency as `High` or `Critical`, formulates a standard paramedic instruction set, and packages the data for an API call directly to the nearest dispatch station.
- **Outcome**: First responders can be alerted before a human dispatcher has finished reviewing the transcript.

### Use Case C: Localized Citizen Guidance
- **Scenario**: A civilian gets trapped inside a smoking office building in Karachi during an electrical fire.
- **Benefit**: The app translates the emergency survival checklists into plain, Roman Urdu instructions (*"Fauri tor par seedhiyon ke zarye building se bahar niklein. Dhuwan hone ki surat me naak ko geele kapray se dhank lein."*).
- **Outcome**: Trapped citizens receive instant, actionable, and readable advice in their preferred dialect, reducing panic and saving lives.

---

## 6. Project Architecture Overview

```
PakBridge AI/
├── src/
│   ├── app/                      # Expo Router File-Based Navigation
│   │   ├── _layout.tsx           # Primary Stack Theme Controller
│   │   ├── index.tsx             # Neural Boot Sequence (Splash)
│   │   ├── (tabs)/               # Bottom Tab Screens
│   │   │   ├── home.tsx          # Incident Command Center
│   │   │   ├── chat.tsx          # Civilian Reporting Interface
│   │   │   ├── dashboard.tsx     # Operations Performance Dashboard
│   │   │   └── map.tsx           # Live Tactical Radar Overlay
│   │   └── workflow/
│   │       └── [id].tsx          # Multi-Agent Workflow Pipeline
│   ├── components/               # Shareable Component Library
│   │   ├── map-view-component    # Cross-Platform Mapping Engine
│   │   └── ui/                   # Reusable Interactive Shells
│   ├── constants/
│   │   └── theme.ts              # Cyber-Dark Style Matrix
│   ├── services/
│   │   ├── geminiService.ts      # Google Generative AI Client & Local Fallback
│   │   └── firebaseConfig.ts     # Remote Database Configuration
│   └── store/                    # Zustand Store State Controllers
│       ├── appStore.ts           # App Language Settings
│       ├── crisisStore.ts        # Active Incident Database
│       └── agentStore.ts         # Agent Workflow Sequence Status
```
