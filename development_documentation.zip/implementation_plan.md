# Authentication & Onboarding System

This plan outlines the implementation of a lightweight registration flow and a geofenced notification system. This allows the app to distinguish between Citizens and Authorities and provide localized emergency alerts based on their registered Home or Office location.

## User Review Required

> [!IMPORTANT]
> - **In-App Notifications**: The current implementation uses custom in-app floating banners instead of native push notifications (which require FCM/APNS setup).
> - **Persistence**: Since `@react-native-async-storage/async-storage` is not in the dependencies, session data will persist in memory for now. I can add persistence if requested.

## Proposed Changes

### [Auth & Session Management]

#### [NEW] [authStore.ts](file:///d:/Projects/PakBridge%20AI/src/store/authStore.ts)
- Define `UserRole` ('Citizen' | 'Authority').
- Define `UserProfile` (name, role, neighborhood, lat, lng).
- Manage registration state.

### [User Interface]

#### [NEW] [onboarding.tsx](file:///d:/Projects/PakBridge%20AI/src/app/onboarding.tsx)
- A stunning, glassmorphic onboarding screen.
- Role selection (Citizen vs. Authority).
- Neighborhood input with auto-resolution via `areaKnowledge.ts`.

#### [MODIFY] [index.tsx](file:///d:/Projects/PakBridge%20AI/src/app/index.tsx)
- Update splash screen to check `isRegistered` status.
- Route to `/onboarding` if user is new, otherwise to `/(tabs)/home`.

#### [MODIFY] [_layout.tsx](file:///d:/Projects/PakBridge%20AI/src/app/_layout.tsx)
- Add a Global Notification Overlay that monitors the `activeReport` and `user` location to show proximity warnings.

### [Notification Logic]

#### [NEW] [NotificationBanner.tsx](file:///d:/Projects/PakBridge%20AI/src/components/NotificationBanner.tsx)
- A reusable floating alert component with distinct styles for "Citizen Warning" vs "Authority Alert".

---

## Verification Plan

### Automated Tests
- `npx tsc --noEmit` to ensure type safety.

### Manual Verification
1. **Onboarding Flow**: Open the app, see the splash screen redirecting to Onboarding.
2. **Registration**: Fill in "Korangi" as a Citizen and submit.
3. **Proximity Check**: Trigger/View a report in Karachi (e.g., the seed Heatwave report).
4. **Notification**: Verify the "Nearby Emergency" banner appears with safe evacuation advice.
5. **Authority Toggle**: Reset session, register as Authority in "Gulberg", and verify alerts for Lahore reports.
