# Firebase Cloud Integration Walkthrough

I have successfully migrated PakBridge AI from a local-only prototype to a scalable, real-time cloud-backed infrastructure using **Firebase**.

## 🚀 Key Improvements

### 1. Persistent Real-Time Data
- **Crisis Reports**: Now stored in a Firestore collection (`crisis_reports`). Any change made in the database (or by another user/agent) syncs to all connected devices in **real-time** using `onSnapshot`.
- **Automatic Seeding**: If the database is empty, the system automatically seeds it with our high-fidelity "Swat Flood" and "Lahore Medical" scenarios.

### 2. Cloud-Synced Profiles
- **Firebase Auth**: Integrated Anonymous Authentication. Users are assigned a unique cloud ID (UID) upon registration.
- **User Profiles**: Name, Role, and Neighborhood coordinates are now saved in Firestore (`users/{uid}`). Your profile follows you even if the app state is cleared locally.

### 3. Smart Notifications (FCM + Expo)
- **Push Token Registration**: During onboarding, the app now requests push notification permissions and saves the device's **Expo Push Token** to the user's Firestore profile.
- **Localized Logic**: The app is now primed to receive remote notifications targeted at specific neighborhoods or roles.
- **Notification Service**: Added `src/services/notificationService.ts` to manage native alert channels and token logistics.

### 4. Robust Startup Flow
- **Neural Sync**: The Splash screen now waits for Firebase Auth to initialize before deciding whether to send the user to Onboarding or the Command Center.

## 🛠️ Updated Architecture

- **[authStore.ts](file:///d:/Projects/PakBridge%20AI/src/store/authStore.ts)**: Handles cloud login and profile syncing.
- **[crisisStore.ts](file:///d:/Projects/PakBridge%20AI/src/store/crisisStore.ts)**: Replaced local array with Firestore real-time queries.
- **[notificationService.ts](file:///d:/Projects/PakBridge%20AI/src/services/notificationService.ts)**: New service for native push alerts.
- **[firebaseConfig.ts](file:///d:/Projects/PakBridge%20AI/src/services/firebaseConfig.ts)**: Fully configured with your project credentials.

## 🧪 How to Verify
1. **Real-Time Sync**: Open the app on two different devices/simulators. If you update a report's status in the Firestore console, it will update instantly on both devices.
2. **Persistence**: Register as a user, close the app, and reopen. Your profile should be fetched immediately from the cloud.
3. **Notifications**: On a physical device, you will be prompted for notification permissions during onboarding.
