# Authentication & Geofenced Notifications Walkthrough

I have implemented a lightweight authentication system that allows PakBridge AI to distinguish between **Citizens** and **Authorities**, providing personalized, geofenced emergency alerts.

## Key Accomplishments

### 1. Unified Auth Store
Created [authStore.ts](file:///d:/Projects/PakBridge%20AI/src/store/authStore.ts) using Zustand to manage:
- User Profile (Name, Role, Neighborhood).
- Automatic coordinate resolution using the `areaKnowledge` service.
- Persistence (in-memory) and session management.

### 2. High-Fidelity Onboarding
Developed [onboarding.tsx](file:///d:/Projects/PakBridge%20AI/src/app/onboarding.tsx):
- Stunning glassmorphic design with role-based icons.
- Smooth transitions using `react-native-reanimated`.
- Intuitive location entry that links users to Pakistan's regional grid.

### 3. Smart Startup Routing
Updated [index.tsx](file:///d:/Projects/PakBridge%20AI/src/app/index.tsx):
- The splash screen now intelligently checks if a user is registered.
- New users are funneled to Onboarding; returning users bypass directly to the Command Center.

### 4. Geofenced Notification Banner
Created [NotificationBanner.tsx](file:///d:/Projects/PakBridge%20AI/src/components/NotificationBanner.tsx):
- Watches all incoming crisis reports in real-time.
- Calculates proximity (within ~3.8km) to the user's home or office.
- Displays a role-specific floating warning (Citizen Warning vs. Authority Alert).
- Clicking the banner opens the AI Workflow for that specific crisis.

### 5. Profile Management
Enhanced [home.tsx](file:///d:/Projects/PakBridge%20AI/src/app/%28tabs%29/home.tsx):
- Added a Profile Summary card at the top.
- Integrated a "Reset Session" button (Logout icon) in the header for easy testing and role switching.

## Verification Results
- **Type Safety**: Verified with `npx tsc --noEmit` (Exit Code 0).
- **Navigation**: Confirmed clean routing between Splash -> Onboarding -> Home.
- **Logic**: Geofenced alerts trigger correctly when a report's coordinates match the user's neighborhood bounds.

---

## How to Test
1. **Reset Session**: Click the logout icon in the top right of the Home screen.
2. **Onboarding**: Register as a **Citizen** with neighborhood "Korangi".
3. **Trigger Alert**: View the report for "Karachi Heatwave". Since you are in Korangi (Karachi), you should see a floating "Immediate Danger Warning".
4. **Authority Test**: Reset session, register as **Authority** with neighborhood "Gulberg". View the "Lahore Medical Distress" report. You will see an "Authority Mobilization" alert.
