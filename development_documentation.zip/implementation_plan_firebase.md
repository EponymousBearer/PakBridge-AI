# Firebase Integration Plan

This plan outlines the migration from a local-only setup to a robust Firebase-backed infrastructure for authentication, data storage, and notifications.

## User Review Required

> [!IMPORTANT]
> - **Firebase Login**: I need you to visit the following URL to log in and provide the authorization code: [Firebase Login](https://auth.firebase.tools/login?code_challenge=UiRaIRrwloHxOBfbfVWebO_9Z2QAC07FCp7zv7MccGc&session=c9cb1efb-5581-403b-81ab-670841830229&attest=vzuldwBEHFdeJZS5-2U7sqqOf0u1pDWsu9EBCoypmMQ&studio_prototyper=true)
> - **Project ID**: Please specify if you have an existing Firebase project ID or if I should create a new one for PakBridge AI.
> - **Notification Strategy**: I will use `expo-notifications` to handle push tokens and receive messages.

## Proposed Changes

### [Firebase Setup]

#### [MODIFY] [.env](file:///d:/Projects/PakBridge%20AI/.env)
- Add `EXPO_PUBLIC_FIREBASE_*` configuration keys.

#### [MODIFY] [firebaseConfig.ts](file:///d:/Projects/PakBridge%20AI/src/services/firebaseConfig.ts)
- Add Firebase Auth and Cloud Messaging initialization.

### [Authentication & Profiles]

#### [MODIFY] [authStore.ts](file:///d:/Projects/PakBridge%20AI/src/store/authStore.ts)
- Integrate Firebase Anonymous Auth.
- Save/Sync `UserProfile` to Firestore `users/{uid}` collection.

### [Notifications]

#### [NEW] [notificationService.ts](file:///d:/Projects/PakBridge%20AI/src/services/notificationService.ts)
- Logic for requesting permissions, getting Expo push tokens, and storing them in Firestore.

#### [MODIFY] [NotificationBanner.tsx](file:///d:/Projects/PakBridge%20AI/src/components/NotificationBanner.tsx)
- Add support for displaying remote push notifications when the app is in foreground.

### [Crisis Data]

#### [OPTIONAL] [crisisStore.ts](file:///d:/Projects/PakBridge%20AI/src/store/crisisStore.ts)
- Migrate `INITIAL_REPORTS` to a `crisis_reports` Firestore collection for real-time sync across devices.

---

## Verification Plan

### Automated Tests
- `npx tsc --noEmit` to ensure type safety.

### Manual Verification
1. **Login**: Verify successful registration creates a user in Firebase Auth and Firestore.
2. **Persistence**: Reload app and ensure profile is fetched from Firestore.
3. **Notification**: Simulate a notification via Firebase Console (or MCP) and verify it reaches the device/emulator.
